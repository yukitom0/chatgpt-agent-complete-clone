const crypto = require('crypto');

/**
 * Sign an HTTP request using a simple HMAC scheme.
 * In production you would implement RFC 9421 signing for stronger security.
 *
 * @param {string} method - HTTP method (GET, POST, etc.)
 * @param {string} url - Request URL
 * @param {object} headers - Headers to include in the signature
 * @param {string|Buffer} body - Request body
 * @param {string} secret - Secret key used for signing
 * @returns {string} - Hex-encoded signature
 */
function signRequest(method, url, headers = {}, body = '', secret) {
  const normalizedHeaders = Object.keys(headers)
    .sort()
    .map(key => `${key.toLowerCase()}:${headers[key]}`)
    .join('\n');
  const content = `${method.toUpperCase()} ${url}\n${normalizedHeaders}\n${body}`;
  return crypto.createHmac('sha256', secret).update(content).digest('hex');
}

module.exports = { signRequest };
