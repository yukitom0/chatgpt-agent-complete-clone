const schedule = require('node-schedule');

/**
 * Schedules a job to run every five minutes.
 * In a real system this could trigger the orchestrator or other tasks.
 */
function job() {
  console.log('Scheduled task executed at', new Date().toISOString());
}

// Cron-like expression: every 5 minutes
schedule.scheduleJob('*/5 * * * *', job);

console.log('Scheduler started');
