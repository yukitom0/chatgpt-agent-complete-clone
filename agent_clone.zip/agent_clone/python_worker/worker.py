def main():
    """
    Example Python worker that prints a message.
    This simulates a lightweight sandbox used by the orchestrator.
    """
    print("Hello from the Python worker!")

if __name__ == "__main__":
    main()
